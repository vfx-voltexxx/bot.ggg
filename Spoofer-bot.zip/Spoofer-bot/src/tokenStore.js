import crypto from 'node:crypto';
import fs from 'node:fs';

const FILE = 'tokens.json';
const ALG = 'aes-256-gcm';

function key(secret) {
  return crypto.createHash('sha256').update(secret || 'spoofer').digest();
}
function enc(text, k) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv(ALG, k, iv);
  const data = Buffer.concat([c.update(text, 'utf8'), c.final()]);
  return JSON.stringify({ iv: iv.toString('hex'), tag: c.getAuthTag().toString('hex'), data: data.toString('hex') });
}
function dec(raw, k) {
  try {
    const { iv, tag, data } = JSON.parse(raw);
    const d = crypto.createDecipheriv(ALG, k, Buffer.from(iv, 'hex'));
    d.setAuthTag(Buffer.from(tag, 'hex'));
    return d.update(Buffer.from(data, 'hex')) + d.final('utf8');
  } catch { return null; }
}
function load() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return {}; }
}
function save(s) { fs.writeFileSync(FILE, JSON.stringify(s, null, 2)); }

export class TokenStore {
  constructor(secret) { this.k = key(secret); }

  save(userId, token, meta = {}) {
    const s = load();
    const prev = s[userId]?.meta || {};
    s[userId] = {
      blob: enc(token, this.k),
      meta: {
        linkedAt: Date.now(),
        totalGames: prev.totalGames || 0,
        totalHours: prev.totalHours || 0,
        cookie: prev.cookie || null,
        fingerprint: prev.fingerprint || null,
        discordId: prev.discordId || null,
        ...meta,
      },
    };
    save(s);
  }

  get(userId) {
    const s = load()[userId];
    if (!s?.blob) return null;
    return dec(s.blob, this.k);
  }

  getMeta(userId) {
    return load()[userId]?.meta || null;
  }

  setMeta(userId, patch) {
    const s = load();
    if (!s[userId]) return false;
    s[userId].meta = { ...(s[userId].meta || {}), ...patch };
    save(s);
    return true;
  }

  addStats(userId, games, hours) {
    const m = this.getMeta(userId) || {};
    this.setMeta(userId, {
      totalGames: (m.totalGames || 0) + games,
      totalHours: (m.totalHours || 0) + hours,
    });
  }

  remove(userId) {
    const s = load();
    if (!s[userId]) return false;
    delete s[userId];
    save(s);
    return true;
  }

  has(userId) { return !!this.get(userId); }
}
