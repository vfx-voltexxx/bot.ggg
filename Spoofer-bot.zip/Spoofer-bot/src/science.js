import crypto from 'node:crypto';

const ME_URL = 'https://discord.com/api/v9/users/@me?with_analytics_token=true';
const SCIENCE_URL = 'https://discord.com/api/v9/science';
const GAMES_CDN = 'https://cdn.discordapp.com/detectables/games.json';
const PROPS_URL = 'https://cordapi.dolfi.es/api/v2/properties/windows';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9253 Chrome/134.0.6998.205 Electron/35.3.0 Safari/537.36';

const CLIENT_VERSION = '1.0.9253';
const CLIENT_BUILD = 420000;
const NATIVE_BUILD = 65000;
const OS_VERSION = '10.0.26200';

function b64props(obj) {
  return Buffer.from(JSON.stringify(obj)).toString('base64');
}

function localProps(launchSig, hbSession) {
  return {
    os: 'Windows',
    browser: 'Discord Client',
    release_channel: 'stable',
    client_version: CLIENT_VERSION,
    os_version: OS_VERSION,
    os_arch: 'x64',
    app_arch: 'x64',
    system_locale: 'en-US',
    has_client_mods: false,
    browser_user_agent: UA,
    browser_version: '35.3.0',
    os_sdk_version: '26200',
    client_build_number: CLIENT_BUILD,
    native_build_number: NATIVE_BUILD,
    client_event_source: null,
    client_app_state: 'focused',
    client_launch_id: crypto.randomUUID(),
    launch_signature: launchSig,
    client_heartbeat_session_id: hbSession,
  };
}

async function buildSuperProps(launchSig, hbSession) {
  try {
    const res = await fetch(PROPS_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'user-agent': UA },
      body: '{}',
    });
    if (res.ok) {
      const j = await res.json();
      const props = j.properties || j;
      props.client_launch_id = crypto.randomUUID();
      props.launch_signature = launchSig;
      props.client_heartbeat_session_id = hbSession;
      return b64props(props);
    }
  } catch {}
  return b64props(localProps(launchSig, hbSession));
}

export async function fetchAnalyticsToken(userToken) {
  const launchSig = crypto.randomUUID();
  const hb = crypto.randomUUID();
  const superProps = await buildSuperProps(launchSig, hb);
  const res = await fetch(ME_URL, {
    headers: {
      authorization: userToken,
      'user-agent': UA,
      'x-super-properties': superProps,
    },
  });
  if (!res.ok) throw new Error(`token rejected (${res.status})`);
  const data = await res.json();
  if (!data.analytics_token) throw new Error('no analytics_token');
  return { analyticsToken: data.analytics_token, me: data, superProps, launchSig, hb };
}

let gamesCache = null;
export async function loadGames() {
  if (gamesCache) return gamesCache;
  const res = await fetch(GAMES_CDN, { headers: { 'user-agent': 'Mozilla/5.0' } });
  if (!res.ok) throw new Error('games list failed');
  const data = await res.json();
  const games = [];
  const seen = new Set();
  for (const entry of data) {
    const id = String(entry.id || '');
    if (!/^\d+$/.test(id) || seen.has(id)) continue;
    const exe = (entry.executables || []).find((e) => e.os === 'win32' && e.name);
    if (!exe) continue;
    seen.add(id);
    games.push({ id, name: entry.name || id, exe: exe.name });
  }
  gamesCache = games;
  return games;
}

function buildLaunch(game, session, seq) {
  const now = Date.now();
  return {
    type: 'launch_game',
    properties: {
      client_track_timestamp: now,
      client_heartbeat_session_id: session.hb,
      event_sequence_number: seq,
      game: game.name,
      game_id: game.id,
      verified: true,
      elevated: false,
      is_launcher: false,
      game_platform: 'desktop',
      detection_method: 'verified_game',
      is_overlay_enabled: false,
      is_overlay_game_enabled: true,
      is_overlay_game_source: 'OOP_DEFAULT_DATABASE',
      fullscreen_type: 'UNKNOWN',
      hardware_display_count: 1,
      overlay_method: 'Disabled',
      activity_status_enabled: true,
      activity_status_shared_guilds: [],
      current_user_status: 'online',
      game_detection_enabled: true,
      executable_path: game.exe,
      voice_channel_id: null,
      voice_channel_type: null,
      voice_channel_bitrate: null,
      voice_channel_guild_id: null,
      hidden_by_distributor: false,
      game_metadata: null,
      client_performance_cpu: null,
      client_performance_memory: null,
      cpu_core_count: null,
      accessibility_features: 0,
      rendered_locale: 'en-US',
      launch_signature: session.launchSig,
      client_rtc_state: null,
      client_app_state: 'focused',
      client_send_timestamp: now,
    },
  };
}

function buildHeartbeat(game, session, seq, durationMs, { initial = false, final = false, ts = Date.now() } = {}) {
  return {
    type: 'running_game_heartbeat',
    properties: {
      client_track_timestamp: ts,
      client_heartbeat_session_id: session.hb,
      event_sequence_number: seq,
      game: game.name,
      game_id: game.id,
      game_session_id: session.gameSessionId,
      duration_tracked_ms: durationMs,
      verified: true,
      elevated: false,
      is_launcher: false,
      game_platform: 'desktop',
      detection_method: 'verified_game',
      initial,
      final,
      launch_signature: session.launchSig,
      client_app_state: 'focused',
      client_send_timestamp: ts,
      rendered_locale: 'en-US',
    },
  };
}

function buildSession(game, session, seqRef, durationMs) {
  const sid = crypto.randomUUID();
  session.gameSessionId = sid;
  const now = Date.now();
  const start = Math.max(0, now - durationMs);
  const events = [];
  events.push(buildHeartbeat(game, session, ++seqRef.n, 0, { initial: true, final: false, ts: start }));
  events.push(buildLaunch(game, session, ++seqRef.n));
  events.push(buildHeartbeat(game, session, ++seqRef.n, durationMs, { initial: false, final: true, ts: now }));
  return events;
}

async function postScience(analyticsToken, superProps, userToken, events) {
  const body = JSON.stringify({ token: analyticsToken, events });
  const res = await fetch(SCIENCE_URL, {
    method: 'POST',
    headers: {
      authorization: userToken,
      'content-type': 'application/json',
      'user-agent': UA,
      'x-super-properties': superProps,
    },
    body,
  });
  return res.status;
}

/**
 * Spoof N games at hours each (default 1h per game → total hours = N).
 * Matches badge bot: spoof 5000 → 5000 games / 5000.0h
 */
export async function runSpoof(userToken, gameCount, onProgress) {
  const { analyticsToken, me, superProps, launchSig, hb } = await fetchAnalyticsToken(userToken);
  const games = await loadGames();
  if (!games.length) throw new Error('no games loaded');

  const selected = [];
  for (let i = 0; i < gameCount; i++) {
    selected.push(games[i % games.length]);
  }

  const durationMs = 3600 * 1000; // 1 hour tracked per game
  const session = { launchSig, hb, gameSessionId: null };
  const seqRef = { n: 0 };
  const BATCH = 15; // games per science post (3 events each → 45 events)
  let credited = 0;
  let lastStatus = 0;

  for (let i = 0; i < selected.length; i += BATCH) {
    const chunk = selected.slice(i, i + BATCH);
    const events = [];
    for (const g of chunk) {
      events.push(...buildSession(g, session, seqRef, durationMs));
    }
    lastStatus = await postScience(analyticsToken, superProps, userToken, events);
    if (lastStatus === 204 || lastStatus === 200) {
      credited += chunk.length;
    } else if (lastStatus === 401 || lastStatus === 403) {
      throw new Error(`science rejected (${lastStatus}) — token or rate limit`);
    }
    if (onProgress) onProgress(credited, gameCount, lastStatus);
    await new Promise((r) => setTimeout(r, 800));
  }

  return {
    credited,
    total: gameCount,
    hours: credited,
    status: lastStatus,
    username: me?.username,
    userId: me?.id,
  };
}

export async function checkToken(userToken) {
  const res = await fetch('https://discord.com/api/v9/users/@me', {
    headers: { authorization: userToken },
  });
  if (!res.ok) return { ok: false, status: res.status };
  const me = await res.json();
  return { ok: true, me };
}
